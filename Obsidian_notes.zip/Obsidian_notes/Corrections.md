
- modifier le data type et la table de décision directement sur dev(pas sur une new branche)
- mettre a jour les impacts
Test sur dev : TS_TESTSUITSALTO

Salto_build (import les modifs du dev sur staging : chaque 2heures)