
[16/11/23 10:49] VIALA Coline

Cyriaque, pour mémorisation, tu trouveras ici un récapitulatif des différentes tâches pour les imputations sur JIRA:

- Lien vers le dashboard pour consulter des informations sur le SCRUM (dont le timesheet avec les imputations des différents équipiers) : [https://portail.agir.orange.com/secure/Dashboard.jspa?selectPageId=24360](https://portail.agir.orange.com/secure/Dashboard.jspa?selectPageId=24360 "https://portail.agir.orange.com/secure/dashboard.jspa?selectpageid=24360")
- Lien vers la sous-tache de tests de montée de version : [https://portail.agir.orange.com/browse/SALTO-20004](https://portail.agir.orange.com/browse/SALTO-20004 "https://portail.agir.orange.com/browse/salto-20004")
- Lien vers les points équipes (V1,V2..) [https://portail.agir.orange.com/browse/SALTO-20008](https://portail.agir.orange.com/browse/SALTO-20008 "https://portail.agir.orange.com/browse/salto-20008")
- Lien vers les points transverses (RH, ..) [https://portail.agir.orange.com/browse/SALTO-20009](https://portail.agir.orange.com/browse/SALTO-20009 "https://portail.agir.orange.com/browse/salto-20009")
- Lien vers l'anomalie sur laquelle tu travaillais hier avec Alexandre.  [https://portail.agir.orange.com/browse/SALTO-20118](https://portail.agir.orange.com/browse/SALTO-20118 "https://portail.agir.orange.com/browse/salto-20118")

Pour rappel, pour les points transverses / particulier, si tu ne sais pas où imputer, n'hésite pas à revenir vers moi. Il me semble que les points n'ont pas été saisis sur la bonne tâche. ![🙂](https://statics.teams.cdn.office.net/evergreen-assets/personal-expressions/v2/assets/emoticons/smile/default/20_f.png "Sourire")

Merci de faire plus attention à l'avenir s'il-te-plait ![🙂](https://statics.teams.cdn.office.net/evergreen-assets/personal-expressions/v2/assets/emoticons/smile/default/20_f.png "Sourire")

Dashboard - JIRA for Orange