
Tuteur, Encadrant

3 - peut etre 

4 - Flexible Engine bas

5/ C'est quoi Business BPN ?

6 image non lisible

8 -  c'est quoi le message de l'image :  ?

9 - Bon mais un peu trop de temps ??

12 - pas lisible  ( si pas lisible, retirer)

//Pourquoi numerotation ssans numerotation

16 - Bon mais image pas lissible

NB : est-ce possible de d'indiquer les parties sur les images ?? (ex 19, 20)

21 - pourquoi dans une minutes, c'était du à quoi ?

22 - les texte réduire si possible

23 + 24 : Redondant (tu te repecte)


