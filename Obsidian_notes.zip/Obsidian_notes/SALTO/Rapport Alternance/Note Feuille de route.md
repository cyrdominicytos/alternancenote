
Feuille de route 

Au cours de mon alternance, ma mission a consisté à participer activement à l'ensemble des tâches techniques et fonctionnelles liées au projet. Ces tâches comprennent principalement : 

- Participation aux cérémonies agiles (Daily, Backlog Refinement, Validation Technique, Démo, Rétrospective, etc.). 
    
- Analyse des User Stories (US) et des bugs. 
    
- Développement des US sur la plateforme PEGA. 
    

- Correction des bugs sur la plateforme PEGA. 
    
- Conception et réalisation des tests (preuves de tests, tests de qualification, tests de montée de version, etc.). 
    
- Rédaction ou mise à jour des spécifications fonctionnelles détaillées (SFD). 
    
- Documentation : mise à jour des cartes JIRA et documentation des actions de mise en production (MEP) pour un meilleur suivi de l’avancement des tâches et une facilitation des mises en production. 
    
- Déploiement : déploiement de nouvelles versions de release ou de patch sur les différents environnements. 
    
- Présentation des User Stories développées pour validation fonctionnelle auprès du Product Owner (PO) ou démonstration aux clients en fin de sprint. 
    
- Assurer le support client.