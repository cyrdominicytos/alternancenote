
Agile SAFe
[Le framework SAFe : démystification par un RTE (hubvisory.com)](https://www.hubvisory.com/fr/blog/le-framework-safe-demystification-par-un-rte)

Méthodologie 

Scrum (US) vs KANBAN (Bug) : spécificité et différence

# Agile SAFe, SCRUM, KANBAN

Agile SAFe : cadre agile permettant la gestion itérative de projet à l'echelle d'une entreprise. Permet de gérer plusieurs équipes agile.

Scrum : une méthode agile permettant la gestion itérative de projet à l'échelle d'une équipe. Intègre des sprint court pour avec des feedbacks réguliers sur l'avancement du dev.

Kanban : méthode agile qui met l'accent sur la visualisation du flux de travail et la gestion des tâches en cours. (cartes, colonnes, limite le max d'encours pour éviter les surcharges)

# API REST, Web services

Web service : application ou fonctionnalité accessible via le web. Permet à différentes appli de communiquer sur un réseau en utilisant des protocol :
SOAP : basé sur du XML et permettant des échange HTTP, SMTP
REST : plus flexible et simple que SOAP





