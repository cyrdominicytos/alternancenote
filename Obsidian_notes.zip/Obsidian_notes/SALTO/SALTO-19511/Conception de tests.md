

Configurer une activité facultative comme absente par défaut  : ok 

Configurer une activité facultative comme présente par défaut  : 

Configurer une activité facultative comme présente selon certaines conditions (Cas où la condition de présence est remplie)

Configurer une activité facultative comme présente selon certaines conditions (Cas où la condition de présence n'est pas remplie)


===================
Catalogue  : partenaire orange qui dit quel activité est  présente dans le plan de fab en fonction des paramètres de l'OF

Facultatif 

ST : contient toutes les activés avec les conditions de présence

Condition de présence : appliquée aux activités pour dé


Env catalogue : dev > application > wizard

Nouveau > Dossier de conception de service

Creer un dossier 