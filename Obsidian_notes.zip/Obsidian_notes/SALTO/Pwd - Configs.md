
PWD de modif de ruleset en mode dev : retrocow

Elearning coorpacademy : loginsopra/ Test@2024

WhenRule to set all activity parameters with ActivityCode=2064 as optional.

We return true to evaluate all activity parameters as optional in the circumstance ActivityCode=2064.