
Total :  20 + 11 + 1 = 

12 au 30 Aout. soit (15 jours) (Restant 17)