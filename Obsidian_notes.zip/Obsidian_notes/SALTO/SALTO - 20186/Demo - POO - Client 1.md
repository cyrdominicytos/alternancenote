
Objectif US :  Le but de cette US est de reprendre les développements des US [~~SALTO-14613~~](https://portail.agir.orange.com/browse/SALTO-14613 "[XCONF] – Traitement des messages reçus") et [~~SALTO-19742~~](https://portail.agir.orange.com/browse/SALTO-19742 "[XCONF] – Modification Traitement des messages reçus XCONF ZBUS") en prenant en compte les modifications qui ont été apportées par XCONF dans la réponse ZBUS (application des préconisations ZBUS).


DPS1 : 
DPS2 : 
DPS3 : 
DPS4 :

|| Nom || Prenom ||


```xml
<h1 name="nom">blabla</h1>


```

T1A : 
T1B : 


T2A: 
T3 : 

![[Pasted image 20240112161515.png]]



DFLLG

[[Conception de tests - Guide#Ecrire et utiliser d'autres Tests le plus que possible]]