
Objectif US :  Le but de cette US est de reprendre les développements des US [~~SALTO-14613~~](https://portail.agir.orange.com/browse/SALTO-14613 "[XCONF] – Traitement des messages reçus") et [~~SALTO-19742~~](https://portail.agir.orange.com/browse/SALTO-19742 "[XCONF] – Modification Traitement des messages reçus XCONF ZBUS") en prenant en compte les modifications qui ont été apportées par XCONF dans la réponse ZBUS (application des préconisations ZBUS).

**Attention** : S'assurer que le jobScheduler #ProcessZbusXconfSubscribedStreams" est bien désactivé sur dev et activé sur staging avant le test.

RAP : SDS0001
Cycle : 1

**UC1 : Traitement d'un événement ZBUS XCONF OK**

DPS-24279
DPS-24280

SALTO reçoit un événement ZBUS dont le champ data.state vaut Successful et dont la ressource et l'activityGroup sont associés à l'activité dans la table des événements externes :

- l'activité passe à l'état "Terminé"
- un message est ajouté dans l'historique de l'activité de type "Informations techniques" avec la description :
"_La demande  "{Libellé de l’activité}" a été terminée dans l’application XCONF._"



**UC2 : Traitement d'un événement ZBUS XCONF NOK**

DPS-24281
DPS-24282

SALTO reçoit un événement ZBUS de la part de XCONF dont le champ data.state vaut Failed/Partially Successful/NA et dont la ressource et l'activityGroup sont associés à l'activité dans la table des événements externes :

- l'activité passe à l'état "En erreur"
- une tâche est distribuée avec un écran permettant de relancer l'appel à XCONF
- le message d'erreur suivant est affiché :

"_Suite à la réception d’un événement de l’application XCONF le {date_heure}, un problème a été détecté : Description du message : data.errorMessage.message  – le rapport est visible à l’adresse " data.urlReport_ "

- Un message est ajouté dans l'historique de l'activité de type "Infos techniques" avec la description :

"_La demande "{Libellé de l’activité}" a échoué dans l’application XCONF : {Description du message : data.errorMessage.message + " – le rapport est visible à l’adresse " + data.urlReport_  }."

**UC3 : Pas d’événement ZBUS XCONF à traiter**

Si aucun événement n’est reçu avant le délai de remontée en alerte de l'activité :

- l’activité passe dans l'état "En erreur".
- une tâche est distribuée avec un écran permettant de relancer l'appel à XCONF.
- le message d'erreur suivant est affiché :

"_Suite à l'appel vers l'application XCONF par <prénom nom de l’utilisateur> le < date heure>, un problème a été détecté : Le délai de réception de la réponse de XCONF est expiré._"

- un message est ajouté dans l'historique de l'activité de type "Alertes" avec la description :

"_Aucune information n'a été reçue de l'application XCONF et la date limite de réalisation est maintenant dépassée._"