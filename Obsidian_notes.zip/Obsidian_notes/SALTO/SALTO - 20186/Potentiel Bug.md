Test sur staging
RAP : SDS0001
Cycle : 1
# Tester mise en service du routeur SDWAN XCONF"

Seul test passant pour l'activité : "Tester mise en service du routeur SDWAN XCONF"
![[Pasted image 20240115164612.png]]

 Lorsque  "activityGroup": "acceptanceTest" et le reste identique (*Test en erreur*)
 Lorsque  "activityGroup": "blabla" et le reste identique (*Test en erreur*)
 Lorsque  "activityGroup": "serviceAcceptanceTest" et le reste identique (Test succès) 
 
# ""Tester l'accessibilité du routeur SDWAN XCONF"

![[Pasted image 20240115172116.png]]
Test passant pour "Tester l'accessibilité du routeur SDWAN XCONF"
Idem comme précédemment ou activityGroup = "acceptanceTest"

Lorsque  "activityGroup": "acceptanceTest" et le reste identique (*Test succès)
Lorsque  "activityGroup": "blabla" et le reste identique (*Test en erreur*)
Lorsque  "activityGroup": "serviceAcceptanceTest" et le reste identique (Test erreur) 