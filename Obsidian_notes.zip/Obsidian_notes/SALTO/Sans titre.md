
@OBSLib.BelongToRAPFamily(<current-value>) : RAP FAMILY

@(Pega-RULES:String).equalsIgnoreCase(.ScopeRAP, <current-value>) = true : RAP

@PageExists(".ST.InterventionInformation") : IsInitialized

!@PropertyHasValue(.ST.InstSite) || (@PropertyHasValue(.ST.InstSite) && @String.equalsIgnoreCase(.ST.InstSite,"OUI"))  /  / InstSite=OUI or empty

 JDJDFJ
 
![[Pasted image 20240118154259.png]]

![[Pasted image 20240118154307.png]]