

|                   |                       |
| ----------------- | --------------------- |
| SALTO-22497 : bug | Review branch, qualif |
| SALTO-21673       | Faille security       |


Soupçon, jalon, Hiniber


Actions : 

Mettre le bug à OnHold et demander à Marie Pascale plus d'infos sur comment le bug est survenu (manip qui ont été faites.) Ou reposer la question à celui qui à poser le problème pour avoir plus d'infos.

Tous ce passe normalement, selon notre test.


Mettre la carete a On-Hold (Pour avoir plus d'info de Marie Pascale)

Mettre , ou reposer la a qui a poser la question

Plus de détaials 
