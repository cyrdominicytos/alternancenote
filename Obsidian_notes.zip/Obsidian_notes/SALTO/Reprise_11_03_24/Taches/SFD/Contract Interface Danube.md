
![[Pasted image 20240312142000.png]]


US : 
1. [SALTO-17826](https://portail.agir.orange.com/browse/SALTO-17826)

1. [SALTO-17479](https://portail.agir.orange.com/browse/SALTO-17479)
2. [SALTO-17637](https://portail.agir.orange.com/browse/SALTO-17637)
3. [SALTO-17785](https://portail.agir.orange.com/browse/SALTO-17785)

![[Pasted image 20240312170218.png]]

![[Pasted image 20240312170259.png]]


![[Pasted image 20240312170319.png]]