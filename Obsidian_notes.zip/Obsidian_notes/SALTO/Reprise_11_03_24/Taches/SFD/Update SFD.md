
# Liste des correctifs effectués

| Fichiers                                         | Fonctions       | Actions                                                       |
| ------------------------------------------------ | --------------- | ------------------------------------------------------------- |
| TEC-EXP - Exploitation                           | toutes          | Ajout de la description de toutes les fonctions               |
| TEC - PER - Performance                          | TEC-PER-PER     | Création de la fonction  + Ajout de la description            |
| TEC-SEC - Sécurité                               | TEC-SEC-SEC     | Création de la fonction + Ajout de la description             |
| ALT-IHM - Affichage de l'Alerte                  | toutes          | Ajout de la description                                       |
| WS-SAM - Web Services Samarai                    | WS-SAM-REM      | Ajout de la description                                       |
| ALT-GES - Gestion des alertes                    | ALT-GES-ROU-MUT | Mise à jour du titre de la fonction + ajout de la description |
| ALT-GES - Gestion des alertes                    | ALT-GES-COR     | Création de la fonction + Ajout de la description             |
| WS-RST - Services REST                           | WS-RST-RTX      | Création de la fonction + Ajout de la description             |
| WS-BAL - Interrogation adresse de livraison Bali | WS-BAL-REC      | Ajout du titre de la fonction et de sa description            |
| WS-CED - Web Services CEDRE                      | toutes          | Ajout de la description de toutes les fonctions               |
| WS-ERP - Gestion d'ERP                           | WS-ERP-EAL      | Ajout de la description                                       |
| WS-ERP - Gestion d'ERP                           | WS-ERP-EAA      | Création de la fonction + Ajout de la description             |
| WS-ERP - Gestion d'ERP                           | WS-ERP-ERM      | Ajout de la description                                       |
| WS-ARP - Gestion d'ARP                           | WS-ARP-ENV      | Ajout dans la cartographie                                    |
| WS-OT - Web Service OT sous-traitant             | WS-OT-UPD       | Ajout de la description                                       |
| WS-OT - Web Service OT sous-traitant             | WS-OT-DEL       | Ajout de la description                                       |





**Liste des SFD non introuvables**

| Fichiers / Sous Domaine             |
| ----------------------------------- |
| DCA-CFA - Configuration applicative |
| WS-MAL - Web Services MALIMA        |
| WS-SPV - Supervision                |


15/03/2024


|            |                                                                                                                  |             |             |                                                                                              |
| ---------- | ---------------------------------------------------------------------------------------------------------------- | ----------- | ----------- | -------------------------------------------------------------------------------------------- |
| RQ-007     | §4,3,1 : Il manque la vue processus avec l'enchaintement des fonctions<br>ADM-ORG-GUS-E01 RGV001 à supprimer<br> | Non compris |             |                                                                                              |
|            |                                                                                                                  |             |             |                                                                                              |
|            |                                                                                                                  |             |             |                                                                                              |
| 18/03/2024 | Cyriaque TOSSOU                                                                                                  | 1.37.153    | SALTO-20214 | Faire correspondre la fonction “Traitement des OF OPERA Pilot”  au traitement  WS-OPR-OF T02 |

DCS (dossier de conception de service) , DLS (Dossier de lecture de service,  read only on Catalogue).