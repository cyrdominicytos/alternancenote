
Qualif bug :15/04 1. [SALTO-22497](https://portail.agir.orange.com/browse/SALTO-22497)