Objectif de l'US : 

Faire en sorte que l’activité "Commander le routeur" soit automatique dans le cas de la modification d'une antenne xG et manuelle sinon.


- Dans le cas d'une modification d'antenne xG (MODANTENNE=OUI), l'activité "Commander le routeur" soit automatique dans le plan de fabrication en cycle de modification avec possibilité de passage de l'activité en manuel.
- Dans le cas où il n'y a pas de modification d'antenne xG (MODANTENNE<>OUI), l'activité "Commande routeur" soit manuelle dans le plan de fabrication en cycle de modification.

Déroulement du test :


Modification d'une antenne xG 
Nominal case (MODANTENNE = « OUI »), 
 Config file: DEV_FIN0027_MODANTENNE_ROUTER_RESS 
 <config>
  <wo>
    <rap>FIN0027</rap>
    <resource role="Nominal" type="TYP160" cycle="2" number="1">
      <param code="MODANTENNE" value="OUI" sec="SC4276"/>
    </resource>
  </wo>
</config>
 Cycle:2


Modification d'une "NON" antenne xG 
Nominal case (MODANTENNE = « NON »), 
 Config file: DEV_FIN0027_MODANTENNE_NON_ROUTER_RESS 
 <config>
  <wo>
    <rap>FIN0027</rap>
    <resource role="Nominal" type="TYP160" cycle="2" number="1">
      <param code="CODPCK" value="K737" sec="SC4276"/>
      <param code="MODANTENNE" value="NON" sec="SC4276"/>
    </resource>
  </wo>
</config>
 Cycle:2
 
# [Modification Antenne xG - Commande routeur automatique avec possibilité en manuel](https://portail.agir.orange.com/browse/SALTO-20810)

Cas de modification d'antenne xG (MODANTENNE=OUI)
1. Nominal case (MODANTENNE = « OUI »)
- Créer un DPS en cycle de modif :  DPS-24240
- l'ouvrir et ajouter l'activité "Commander le routeur" (Elle est par défaut automatique avec la possibilité de la passer en manuel)
- Valider le plan de FAB en la gardant en auto (ne pas cochet la case manuel)
- Faire évoluer le plan de fab jusqu'à atteindre d'activité "Commande router"
- Elle doit s'exécuter de manière auto (erreur du  au ND pres)

2. Nominal case (MODANTENNE = « OUI ») mais passer en manuel
- Créer un DPS en cycle de modif :  DPS-24243
- l'ouvrir et ajouter l'activité "Commander le routeur" (Elle est par défaut automatique avec la possibilité de la passer en manuel)
- Valider le plan de FAB en la passant en manuel (cochet la case manuel)
- Faire évoluer le plan de fab jusqu'à atteindre d'activité "Commande router"
- Elle doit être à réaliser 

Il n'y a pas de modification d'antenne xG (MODANTENNE<>OUI),
3. # [Modification Antenne xG - Commande routeur manuel](https://portail.agir.orange.com/browse/SALTO-20811) (MODANTENNE = « NON »)
    Config file: DEV_FIN0027_MODANTENNE_NON_ROUTER_RESS
- Créer un DPS en cycle de modif :  DPS-24285
- l'ouvrir et ajouter l'activité "Commander le routeur" (par défaut en manuel et pas possible de changer)
- Valider le plan de FAB 
- Faire évoluer le plan de fab jusqu'à atteindre d'activité "Commande router"
- Elle doit être à réaliser 



