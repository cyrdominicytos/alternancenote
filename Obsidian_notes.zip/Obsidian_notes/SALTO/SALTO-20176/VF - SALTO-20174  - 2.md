
Objectif de l'US : 

Faire en sorte que l’activité "Commander le routeur" soit automatique dans le cas de la modification d'une antenne xG et manuelle sinon.


- Dans le cas d'une modification d'antenne xG (MODANTENNE=OUI), l'activité "Commander le routeur" soit automatique dans le plan de fabrication en cycle de modification avec possibilité de passage de l'activité en manuel.
- Dans le cas où il n'y a pas de modification d'antenne xG (MODANTENNE<>OUI), l'activité "Commande routeur" soit manuelle dans le plan de fabrication en cycle de modification.

Déroulement du test :

Cas de modification d'antenne xG (MODANTENNE=OUI)
  DPS-24240

Cas de modification d'antenne xG (MODANTENNE=OUI) et le passer a manuel
DPS-24243

Il n'y a pas de modification d'antenne xG (MODANTENNE<>OUI),
DPS-24285



