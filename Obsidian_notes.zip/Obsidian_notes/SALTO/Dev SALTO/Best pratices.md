[  
InitCreationProperties](https://web.salto-dev.caas-cnp-apps-v2-ka.com.intraorange/prweb/app/Salto_/X7s5wZdlXtjqua4qic4UwiqXBLXAzpWC*/!TABTHREAD7?pyActivity=%40baseclass.doUIAction&action=openRuleSpecific&openHandle=RULE-OBJ-ACTIVITY%20OBS-FW-SALTOFW-WORK-DPS%20INITCREATIONPROPERTIES%20%2320231201T072001.329%20GMT&Format=harness&contentID=e29b1f6c-7b9e-b1ca-b23b-02c115898522&dynamicContainerID=de12ecd7-b2b3-4849-bff1-ee2797014513&tabIndex=9&prevContentID=835c86bc-ecf2-5129-c3e5-10c0f0b1635a&prevRecordkey=RULE-OBJ-PROPERTY%20OBS-FW-SALTOFW-WORK-DPS%20CATALOGVERSION%20%2320231201T070332.232%20GMT&portalThreadName=STANDARD&portalName=Developer&eventSrcSection=Data-Portal.pzExplorers&pzHarnessID=HIDB458352D3D7C4C72B7E68544FD1B07FA# "Click to edit")

[
!!! - Les modifs des data types et tables de décisions ne sont pas livrées donc tous dev ayant touchés ces élements devront être reproduire sur chaque env

# Modification de Data Type : 
- Après une modif de data type, faire un flush de la data page associée afin de prendre en compte les modifs dans l'appli SALTO. [[Flush data page]]


# Key notes for dev

Faire une table de Decision
ex
HasMandatorySkillToProcess
![[Pasted image 20240423155422.png]]
	![[Pasted image 20240423160512.png]]
Exec la table via un WHEN Rules
ex : HasSkillToProcess

![[Pasted image 20240423155502.png]]




# Check presence conditions of a specific act

![[Pasted image 20240424144434.png]]

# Delete RuleSet

![[Pasted image 20240506131440.png]]

	# Before installing catalog
	
	Empty the data type : actconfigurationOPC

ProccessToLaunch : for DPS processus
# Trace ARP sending processing : ProcessARP


|          |
| -------- |
| ST-10340 |
10109

Vider ACTCONFIGURATION OPC

Activité "Isoler le client"

RAP : BIE0005 (Local internet)

RAP : BIE0005 (Local internet)

 <PARAMETRE CODE="DPMCIBLE" ACTIVITE="N">SALTOPROC</PARAMETRE>

4, 5, 17, 32.

Vider : la table ()

SALTOPROC

DPS : 

La table correspond a la configuration des DES Processus

apps-raw>applications>bpm>catalog>...


Display the IsIsolationDelayNeeded in the correct page
.IsIsolationDelayNeeded = 
Param.IsIsolationDelayNeeded
![[Pasted image 20240425123918.png]]

![[Pasted image 20240502123010.png]]