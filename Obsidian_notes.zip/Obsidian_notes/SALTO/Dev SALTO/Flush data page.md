
# Flush une data page (liée à un data type)
- Rechercher la Data type puis se rendre dans "usage"
![[Pasted image 20240115095612.png]]
- Cliquer sur la data page correspondante puis se rendre dans l'onglet "Load management"
![[Pasted image 20240115095948.png]]
- Cliquer sur "clear data page" puis sur le pop-up cochet "Flush All" et soumettre
![[Pasted image 20240115100023.png]]