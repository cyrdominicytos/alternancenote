
	Dans le fichier : SFD WS-RST - Service REST

# Règles de gestion

|  |  |
| ---- | ---- |
| RG004 | Tous les paramètres d’appel au service sdn_site sont obligatoires, à l’exception des paramètres ‘sec_ele’ et GWMGT. |
# Règles de gestion

![[Pasted image 20240117134543.png]]

|   |   |
|---|---|
|RG021|Tous les paramètres de l'activité "Réserver un site (POST GINI)" sont facultatifs.<br><br>En cas de modification dans le formulaire des valeurs de ces paramètres, ce sont bien les valeurs modifiées qui sont envoyées dans la trame de l’appel au WS GINI sdn_site (POST).|