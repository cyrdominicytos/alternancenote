
**Objectif** : passer les champs de l'activité "Réserver un site (POST GINI)" en optionnel 
(de sorte que GINI renvoie une erreur pour les champs qui l'intéressent) 


Créer un DPS : SDS0002, cycle : 1

Valider le plan de fab en conservant 

DPS-24405

|   |
|---|
|CR_IsADSLVDSL|