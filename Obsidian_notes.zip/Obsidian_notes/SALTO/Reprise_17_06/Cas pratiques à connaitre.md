
# Cas des reprises : BTIC
	 Si le pb lié à la date (date intervention bandeau =  data rdv pilotage intervention)
 Mettre à jour les ressources du DPS avec la date de rdv dans pilotage intervention
 Mettre à jour le fichier excel en mettant a WAIT
 Filtrer sur Non et WAIT (et passer les lignes correspondantes à OK)


//Mettre à jour les reprise

Colonne à coté de Action => filtrer sur Non, puis les passer à OK.

# Cas activité terminée
	Si uniquement Pilotage intervention en cours alors terminer le DPS
	 Si une autre activiter en cours alors contacter le pilotage pour savoir ce qu'il faut faire
	 NB : La terminaison du DPS, le remonte à OPERA (achive la DDP) qui lance la facturation client. 
# 
Après qualif d'un DPS d'annulation le DPS précedent est annulé (les deux devraient avoir les mêmes SU)

# PB : SALTO liste des jalons Remote Id non termines a tort

- Utiliser le Script DB pour supprimer la ligne correspondante
- Chopper le SUID ou le OF ID ()
- Rechercher puis rejouer l'OF (en changeant uniquement la date de l'OF) puis 
- 
# 
