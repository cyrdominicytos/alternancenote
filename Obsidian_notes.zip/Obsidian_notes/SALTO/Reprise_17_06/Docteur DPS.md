
Vert = terminé
Gris =  (Suivant d'un jaune ?) 
Jaune = En attente d'être débloqué ()
Bleu =  ?

Trait rouge = précédents de l'élement (sera débloquer dans tous sont vert)
Trait violet = suivant de l'élement (sa terminaison débloquera les suivants)
