
- Comment se passe la rédaction du rapport (il y a t-il un temps prévu par l'entreprise) ?
- Poser 1 semaine de congés pour rédiger mon rapport et préparer ma soutenance  (semaine du 1 au 5 Juillet)
- Le reste du congés en début d'Août ()
-  Dernière visite du prof : semaine pro (mercredi  16h)


Soutenance Blanche (Brendan, Julien , Coline) => Semaine prochain )

Posser les congés.