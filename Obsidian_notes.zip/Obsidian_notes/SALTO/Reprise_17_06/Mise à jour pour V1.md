
Prendre le mail de Pierrick 

mettre à jour les fichiers

étendre le graphe à la nouvelle semaine

Copier le graphe et le mettre dans le document du V1 (lien en favoris)


# Which info need to provide in V1

![[Pasted image 20240621153515.png]]
