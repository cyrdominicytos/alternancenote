#SDFRE

3838 : renvoyer à SALTO

3961 : passer à SALTO (THAM)

3974  : (23585) chez salto (Florian - Shaswhat)

MEP CATALOG => (08/07) puis 16/09

Problème sur le VPO0010  : Activer le service (voir avec la DA, s'il faut forcer via  le clipboard la sélection)

NOMPRJOSM