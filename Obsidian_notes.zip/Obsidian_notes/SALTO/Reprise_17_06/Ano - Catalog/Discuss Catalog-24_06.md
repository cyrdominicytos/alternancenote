
# SDFRE-3940
OF es

De voir avec Isabelle : faire de l'ajustement (catalogue prisme), ajouter un nouveau paramètre pour configurer le BNG dynamique.

# SDFRE-3838


Vanessa regarde

# SDFRE-3961

Fred - Vanessa

# SDFRE-3980


Activer le service , selected à false sur plusieurs ressources.

# 
Model service : lorsqu'il ne trouve pas le ST