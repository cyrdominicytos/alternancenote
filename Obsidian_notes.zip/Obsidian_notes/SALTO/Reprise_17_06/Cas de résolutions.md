
# 1.  CD0KR3BED8 DPS-1983130
 ![[Pasted image 20240620095347.png]]

Typologie : QuestFonctEtatACT

Anomalie liée : N/A

Contexte : CD0KR3BED8, DPS-1983130

Diagnostic : La DDP précédente a été annulée sans avoir été mise en parc, donc la ressource n'est pas reconnue par CEDRE, ce qui explique sa création actuelle.

Solution/palliatif : Laisser la production continuer ; le problème sera résolu par une resynchronisation à la fin de la production.
 
Cordialement,
Support N3 SALTO / salto.support@soprasteria.com



=======================

# 2. Commande Support FTTH en cours autres act bloquées

![[Pasted image 20240620105146.png]]

Typologie : QuestFonctEtatACT

Anomalie liée : N/A

Contexte : DPS-1822124

Diagnostic : La carte bug avait demandé à ce que l'Activité « Configuration PE BNG Dynamique et Radius » se déclenche lorsque la la commande du support FTTHE soit terminée. Donc, les prochaines étapes se déclencheront lorsque la commande support sera traitée.

Solution/palliatif : Traiter la commande support FTTHE pour faire avancer la fabrication.
 
Cordialement,
Support N3 SALTO / salto.support@soprasteria.com


# 3. Configuration PE BNG bloquer - Jalon remote ID non reçu

Vérifier sur opera la ressource Support FTTHE , si remote ID dispo
puis level le Jalon remote Id

![[Pasted image 20240620113553.png]]
Typologie : QuestFonctReceptionJalon

Anomalie liée : N/A

Contexte : DPS-1920851

Diagnostic : Le jalon de vérification de la disponibilité du remoteID n'a pas été levée ce qui empêche le déclenchement  de l'activité " Configuration PE BNG"

Solution/palliatif : Levée du jalon de vérification de la disponibilité du remoteID.
 
Cordialement,
Support N3 SALTO / salto.support@soprasteria.com


==========

Mise à jour du Wiki

URL : 
ProjetName : 


# 4  Nom de Projet WED non remonté

Bonjour, 

mon projet WED : EDF ENERGIES NOUVELLES >VDS EDF Renouvelables 2024

ne remonte pas sur salto pour les productions suivantes : 

Typologie : ProjetOSMVide

Anomalie liée : N/A

Contexte : DPS-1999506, DPS-1999504, DPS-1999502, DPS-1999500, DPS-1999499, DPS-2001455, DPS-2009864, DPS-1999493, DPS-1999494

Diagnostic : Nom du projet non remonté dans SALTO

Solution/palliatif : Mise à jour  via le clipboard du nom des projets ([NOMPRJOSM](https://web.salto-prod.caas-cnp-apps-v2-ka.com.intraorange/prweb/app/Salto/i1yf9PS_LzpYfgPUj3SUvyRYdHK0okBy*/!OpenPortal_SaltoDev?pyActivity=%40baseclass.pzProcessURLInWindow&pyPreActivity=pzGetClipboardPages&showingAdvance=true&fromChange=true&selectedThread=&selectedThreadLabel=&nodeId=&requestorId=&launchClipboardViewer=true&target=popup&portalThreadName=OpenPortal_SaltoDev&portalName=SaltoDev&eventSrcSection=%40baseclass.pyFindWorkGadget&pzHarnessID=HID600FEBDB129634464C8C0221BB5C282C# "NOMPRJOSM")) et des l'URLs  d'accès ([OpenInWedServicesURL](https://web.salto-prod.caas-cnp-apps-v2-ka.com.intraorange/prweb/app/Salto/i1yf9PS_LzpYfgPUj3SUvyRYdHK0okBy*/!OpenPortal_SaltoDev?pyActivity=%40baseclass.pzProcessURLInWindow&pyPreActivity=pzGetClipboardPages&showingAdvance=true&fromChange=true&selectedThread=&selectedThreadLabel=&nodeId=&requestorId=&launchClipboardViewer=true&target=popup&portalThreadName=OpenPortal_SaltoDev&portalName=SaltoDev&eventSrcSection=%40baseclass.pyFindWorkGadget&pzHarnessID=HID600FEBDB129634464C8C0221BB5C282C# "OpenInWedServicesURL"))   
  
Cordialement,
Support N3 SALTO / salto.support@soprasteria.com


# 5 Référence EBSO présente sur SALTO


Typologie : MauvaisParamOF

Anomalie liée : N/A
 
Contexte : SU CD05LTEE91 / DPS-2023536 Commande routeur avec une référence EBSO incorrecte.
 
Diagnostic : EBSO toujours présent dans SALTO lors de l'envoi de la commande vers PVOT, bien qu'il ne le soit plus dans OPERA.
 
Solution/palliatif : Mise à blanc par Clipboard de la donnée ExpectedEBSO sur l’activité. La commande est réalisable.

Cordialement,
Support N3 SALTO / salto.support@soprasteria.com
 