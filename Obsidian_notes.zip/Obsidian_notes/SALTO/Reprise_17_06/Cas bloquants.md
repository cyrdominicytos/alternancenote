**Demandeur** : CAHN BAPTISTE

**Infos** : Ticket : INC001009925154, DPS-1960783 , DDP : 7469243

**Détails**
L'utilisateur souhaite annuler la commande CLIP, mais la DDP d'annulation ne peut pas être créée car la DDP de création (DDP 7469243) est encore en cours. Est-il possible d'annuler le DPS-1960783 correspondant à cette DDP de création, ou faut-il attendre la fin de la production pour créer la DDP d'annulation ?


