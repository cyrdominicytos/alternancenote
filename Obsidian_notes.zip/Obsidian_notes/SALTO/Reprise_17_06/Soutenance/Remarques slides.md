
Page de garde : date de soutenance

Pas de nominal : point d'entree  / PRINCIPALE

Slide 7 : uniquement donnée fictives


Après slide 9 : Une slide pour le chiffrage des US (BR), suivant la suite , les points définissant la complexité plutot


Virer slide : feuille de route

Avant réalisation : parler des ceremonies agiles, montée en 

PEGA : modelisation et automatisation de processus metiers. 

Prepa explication : web service
Kube : cloud, heberge les pods.

Slide 16 : schema synthétique des étapes 
	explication : modelisation, modifier des règles derrières.

**Fait :** OBS : Orange Business


=========== REVISION RAPPORT ======


- [x] Prendre en compte les observations de Coline et de Julien
- [x] Mettre à jour les références webographiques
- [x] Mettre à jour les figures et leurs références
- [x] Faire si possible schema (validateur, processus de dev, )
- [ ] Faire une lectures complète et faire attentions au fautes de frappes
- [ ] Vérifier la mise en forme