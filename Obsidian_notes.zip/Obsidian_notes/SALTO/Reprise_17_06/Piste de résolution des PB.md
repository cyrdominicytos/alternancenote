
# Problème de Jalon non levé sur cmd

- ouvrir le DPS
- dans clipboard exporter le DPS en XML
- l'ouvrir dans Doctor DPS et récupérer le FabAct du jalon bloquant
- Mettre à jour le DPS, 
- dans clipboard passer le status de Activité en "Rosolved-Completed"
- enregistrer
- Modifier le plan de fab (Annuler)
- Envoyer le message de résolution
- Passer le ticket à l'étape suivante


# Commande routeur expédiée dans PVOT mais non acquittée dans salto (status=en cours)

- Retrait/Rajout de l'act du plan de fab + rejeu de l'OT entrant avec statut (50-expédié).  L'act est en cours / terminée 


# Reprise fichier BUI

The issue was fixed.

The new file with the right values should be sent in about  20 minutes.

Regards,

**Etienne LE COANT**




Hello,

We're working on it and will keep you posted.

Regards,

**Etienne LE COANT**





![[Pasted image 20240705093003.png]]