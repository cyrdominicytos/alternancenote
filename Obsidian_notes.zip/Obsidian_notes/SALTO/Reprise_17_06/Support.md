
Renfort sur le support SN3


Mercredi - Vendredi (9h) point bi-hebdomadaire 

SN2 => entonnoir pour ne pas encombrer  le SN3 ( pour voir s'il faut l'envoyer en ).

![[Pasted image 20240617101225.png]]
Aller la et prendre le plus recent

Chaque lundi recevoir  les tickets créés et/ou résolus la semaine dernière et les 180 jours

Prendre le fichier et l'importer dans le nouveau


Genergy : 

Renevouer un ticket :  (Aller  dans group,  affecter BU pivot)
Demander à un PO/AF si pas de souci

186 (déplacer dans ) -> LOT 2 -< DOnnées

![[Pasted image 20240617151018.png]]


# Débloquer fab qualif

updateActInFabrication ( comment step 3)

# ProcessOW  
comment (9, 15) to replay OF with the same id


# Docteur DPS

exporter le XML du DPS dans la save dir de docteur DPS
le lancer et 

![[Pasted image 20240617163930.png]]


sur le diagramme clique rsur l'activité bloquante

![[Pasted image 20240617164042.png]]


![[Pasted image 20240617164005.png]]