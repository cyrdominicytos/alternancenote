
Quantum : Business Manager 
10 ene au Luxembourg

Ex-Banquier au Toulouse

+++++++++  +++++++++

Quantim : 2007 (Julien Bertim) Société qui se développe par lui même
Specialisé dans le domaine en Bancaire - Société finance

Lui représente en Luxembourg (Banque, L)
Client Luxembourg : BGL, BNP, Cardif ( assurance de BPN) 

Volonté de se dev en Européean (Lisborne, ) : Client (BNP Paris Bas, Crédit agricole, )

Fourchette lux (3, 4 ans) : 50k ( Paris).


# Cap


Front : Angular, VueJs
Back : Java, Spring Boot, PHP, Python, Laravel, Symfony
TU, JUnit 5 ou PhpUnit
Monitoring : Grafana, Elestic Search
CI/CD : Gitlab - CI/CD (script bash, Ansible)
Pratique : TDD, 


Exp 

AKASI 
export (Angular, Java, Spring boot)
Tresorerie (Lava)
