- Sur outlook, télécharger les fichier du jour des dossiers : Reprise N3 et Reprise RUN
- Supprimer le contenu du dossier suivant
![[Pasted image 20240618094531.png]]
- Déplacer les nouveau fichier télécharger dans le dossier ci-dessus
- Commencer par traiter les fichier en chargés un par un (Dossier RUN ou dossier SN3) 
		NB : toujours charger, mettre à jour et enregistrer à la fin

# Les vendredis faire une repasse sur les BTIC en wait


# Sur Genergy suivre les data
