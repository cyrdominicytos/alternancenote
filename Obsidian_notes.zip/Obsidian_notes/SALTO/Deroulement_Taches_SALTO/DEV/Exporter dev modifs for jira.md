
Rechercher jira

choisir  **GetRulesInformationForJira**

![[Pasted image 20240326133856.png]]

Actions > Run
![[Pasted image 20240326133941.png]]

Saisir le num de la branche et valider

![[Pasted image 20240326134101.png]]
Run

![[Pasted image 20240326134145.png]]



![[Pasted image 20240326135828.png]]