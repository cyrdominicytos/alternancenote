


[SALTO-21697 Test conception  : 2
V1 1
SALTO-21725 merge and deploy 1


**SALTO-22068** Analysis 2
[SALTO-215https://portail.agir.orange.com/browse/SALTO-2240736]  mise a jour conception : 2

Les taches onDemand de Minu
https://portail.agir.orange.com/browse/SALTO-22282
https://portail.agir.orange.com/browse/SALTO-22407