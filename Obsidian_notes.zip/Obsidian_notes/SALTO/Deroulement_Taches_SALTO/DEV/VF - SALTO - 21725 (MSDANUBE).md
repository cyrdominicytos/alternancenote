

**Test ServiceOrder KO**

1. open the DPS
DPS-26247
DPS-26242

2. open an activity
3. Go to the salto app in PEGA and execute the data page :  D_WS_PostDanubeCase
Class of   D_WS_PostDanubeCase =>OBS-Int-Danube-Cases)
value of activityPage : pyWorkPage

4. On MSDANUBE APP, retrieve the case created and check it's clipboard ()
![[Pasted image 20240404112935.png]]

NumDDP : 99999999

**Mock content**
reason : Bad request for serviceOrder



**SupplierOderKO**

DPS-26248

NumDDP : 11111111
ServiceOrderID : 222222-222222-222222-222222

**Mock content**
reason : Bad request


Recuperer le numero de prestation clip

RAP :VPO0005 et VPO0050

```
TYPELIGNE = Interlan 1.0
```


How to create commande decorrelée DPS

And in the section TYP178

```
 <PARAMETRE ACTIVITE="O" CODE="CDESUPPANTICIP">Non</PARAMETRE>
 <PARAMETRE ACTIVITE="O" CODE="CDESUPPDECORREL">DECORRELEE</PARAMETRE>
```

