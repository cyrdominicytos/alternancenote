D_WS_GetNumPrestaCLIPForSupOrder

@String.substring(Param.pyHTTPResponseCode,0,1)=="3"

Recup propriété d'une classe
@Utilities.getPropertyPageClass("OBS-FW-SALTOFW-Work-ACT-EquipmentOrdering" , "MODANTENNE") != "OUI"

.MODANTENNE!="OUI"




![[Pasted image 20240328141130.png]]

Num presta (un - check) [ValidateNumPrestaNotEmpty](https://web.salto-dev.caas-cnp-apps-v2-ka.com.intraorange/prweb/app/Salto_/X7s5wZdlXtjqua4qic4UwiqXBLXAzpWC*/!TABTHREAD4?pyActivity=%40baseclass.pzTransformAndRun&pzTransactionId=bc492c103fe2ba86846d7b678c505bc0&pzFromFrame=&pzPrimaryPageName=RH_1&eventSrcSection=Rule-.pzRuleFormToolbarDeleteCheckOut&pzHarnessID=HID19C804A55D47E58C946C719A47021FB3&Purpose=RuleForm&ReadOnly=&HarnessPurpose=RuleForm&FolderKey=&InputEnabled=true&pzCTkn=83876a8396dfa80d4e1c629a1d105efd&pzBFP=%7Bv2%7D833b8f92988b3e8814eb59551846196e&preActivity=ProcessRMAction&preActivityParams=%7B%22InsKeyHandle%22%3A%22%22%2C%22UpdateDateTime%22%3A%22%22%2C%22InMemo%22%3A%22%22%2C%22SkipPreCheckIn%22%3A%22%22%2C%22ReturnValue%22%3A%22%22%2C%22InsKey%22%3A%22%22%2C%22InstanceLockedKey%22%3A%22%22%7D&action=display&harnessName=RuleForm&className=Rule-Obj-Validate&pyDataTransform=%7B%22pyDataTransform%22%3A%22pzGetRMAction%22%2C%22pyDataTransformParams%22%3A%7B%7D%7D&pyPreActivity=doUIAction&pzPrimaryPage=RH_1&checkForNewPage=true&switchtoPOST=true&portalName=Developer&contentID=_blank&readOnlyMode=false# "Click to edit")

![[Pasted image 20240328154832.png]]

![[Pasted image 20240402104144.png]]