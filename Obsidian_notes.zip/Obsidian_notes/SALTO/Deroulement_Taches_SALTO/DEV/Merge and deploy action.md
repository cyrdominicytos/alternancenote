
![[Pasted image 20240402152611.png]]

![[Pasted image 20240402153828.png]]


Deployer les appli qui sont pas dans 

![[Pasted image 20240402161324.png]]
![[Pasted image 20240402161314.png]]

![[Pasted image 20240402161522.png]]

Telecharger

Aller sur staging

![[Pasted image 20240402161920.png]]