PKPBL¨£KN¨HL
https://confluence.constellation.soprasteria.com/pages/viewpage.action?pageId=302912108


![[Pasted image 20240326152301.png]]

![[Pasted image 20240326152413.png]]

Aller sur Salto/tools
Incrementer la version de soapUi dans readme
Run le pipeline


Aller sur salto/salto-deploy
run le pipeline sur ta branche
lancer le step mock-deploy

Aller sur kubernetes dashboard, selectionner l'env (salto-dev sur le nav bar)
verifier que tout est bon dans deployments, puis dans pods

[MapResponseGetNumPresta](https://web.salto-dev.caas-cnp-apps-v2-ka.com.intraorange/prweb/app/Salto_/_2av_mnKtw2F9ZO75TKDevbCpI_rQUIb*/!TABTHREAD8?pyActivity=%40baseclass.pzTransformAndRun&pzTransactionId=326fc5c9bfeee2e2740ae590d39750d5&pzFromFrame=&pzPrimaryPageName=RH_1&eventSrcSection=Rule-.pzRuleFormToolbarDeleteCheckOut&pzHarnessID=HIDF24E28B2B05386043E91605EB22E674E&Purpose=RuleForm&ReadOnly=&HarnessPurpose=RuleForm&FolderKey=&InputEnabled=true&pzCTkn=807672cc435045f3bc6e63f7e720a18b&pzBFP=%7Bv2%7D833b8f92988b3e8814eb59551846196e&preActivity=ProcessRMAction&preActivityParams=%7B%22InsKeyHandle%22%3A%22%22%2C%22UpdateDateTime%22%3A%22%22%2C%22InMemo%22%3A%22%22%2C%22SkipPreCheckIn%22%3A%22%22%2C%22ReturnValue%22%3A%22%22%2C%22InsKey%22%3A%22%22%2C%22InstanceLockedKey%22%3A%22%22%7D&action=display&harnessName=RuleForm&className=Rule-Obj-Model&pyDataTransform=%7B%22pyDataTransform%22%3A%22pzGetRMAction%22%2C%22pyDataTransformParams%22%3A%7B%7D%7D&pyPreActivity=doUIAction&pzPrimaryPage=RH_1&checkForNewPage=true&switchtoPOST=true&portalName=Developer&contentID=_blank&readOnlyMode=false# "Click to edit")