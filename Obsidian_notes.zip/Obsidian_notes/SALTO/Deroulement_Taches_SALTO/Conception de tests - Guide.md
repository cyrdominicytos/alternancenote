# créer un test set pour l'US

Faire create et choisir Test set (Dans jira, top navigation bar)

Mettre le nom de l'US sur le set Test ex : SALTO-13293 - Temporisation des appels BACARA en automatique.

  
# aller sur la carte de la carte de l'US et mettre le Test set

Cliquer sur Add Test > Tests from Test Sets

# créer un Test à partir du Test set

Aller sur la carte du Test set et faire Add Test :

- pour le nom du test mettre le TRIGRAME correspondant au dossier du Test Repository avec son numéro (voir dans le dossier le quel numéro c'est) ex : WS-RST-GSS-026 - blabla

- choisir le Fix version ex : BPM - 1.32.134

# Ecrire et utiliser d'autres Tests le plus que possible

Fouiller dans le Test Repository, dans la partie Tests de staging

  
> Si on veut réutiliser un Test, on peut ajouter le Fix version à notre version et l'ajouter dans le Test set : Add Test > existing Test et l'Id du test. Ensuite aller sur le Test set puis sur le test en question et le modifier (cela va modifier l'instance du test pour le Fix version courant)

  

> Les Tests doivent couvrir tous les AC

  

# Ecrire la description du Test

voir les autres Tests pour exemples, et essayer de prendre des descriptions déjà existante sur le sujet et l'ajuster au besoin

  

# Ajouter le test set dans le test exécution

https://portail.agir.orange.com/browse/SALTO-13594?jql=project%20%3D%2017126%20and%20issuetype%20in%20(10504%2C%2010507)

ex : L1V33I135

> c'est pour qu'il soit en TODO au niveau de l'US

  

# Ajouter le test set dans le test plan

https://portail.agir.orange.com/browse/SALTO-13593?jql=project%20%3D%2017126%20and%20issuetype%20in%20(10506)

ex : L1V33I135

> c'est pour qu'il soit en TODO au niveau de l'US

  

# Passer les tests et le Test Set à Done

Aller dans Workflow > Done

  

# Aller sur l'US et lier tous les tests et le test set à l'US

  

# Aller sur la carte de la conception et vérifier que tout est OK

mettre tout en vert en retirant la croix si c'est OK

  

# Envoyer un message teams

La conception de l'US SALTO-12495 est terminée