Aller sur F2F

![[Pasted image 20240321100222.png]]


Cliquer 1, saisir 1(dans les case de presence), faire les etapes suivante, mettre un commentaire si des cases vides, enregistrer puis soumettre (bouton plus bas).
![[Pasted image 20240321095755.png]]