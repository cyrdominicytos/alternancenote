Pour mettre a jour les SFD

1. Repérer et ouvrir le fichier 
2. Accepter toutes les révisions en cours
3. Apporter les modifications en mettant le fichier en révision
4. Mettre à jour l'historique du fichier (1 tableau souvent sur les 1 ères  pages et mettre (ton nom et prénom, le sprint en cours, l'US ou le bug qui à demandé la mise à jour, une description de chaque mise à jour apportée au doc))
5. Ajouter une ligne dans le fichier FdL du sprint correspondant retraçant quel fichier à été mis à jour

Mail au PO, sCRUM MASTER
# NB

Générale>Gestion des versions>Spécifications>sprint_version>choisir_type_spec>Aller_jusquau_fichier
![[Pasted image 20240314165019.png]]

Domaine => Dossier source
Sous-Domaine => Fichier
Nomenclature => Code de la fonction (1 chapitre du fichier )
Fonction => Titre de la fonction


Liste non exhaustive des formations qui seraient intéressante de faire. 

SFD
- Comment reconnaître les SFD impactées par une US lorsque leurs codes ne sont pas pas tagués sur l'US sur jira.

Env
- Une brève explication de tous les environnements de SALTO et leurs spécificités.

Dev
- Processus importants à garder en tête lors du dev d'une US sur SALTO (quoi mettre en description sur jira, sur confluence, les statuts).

Processus SALTO
- Rôle des applications connexes à SALTO.

Et bien évidemment toutes autres formations que tu jugerais utile au regard de mon bilan actuel.