
![[Pasted image 20240409090319.png]]

![[Pasted image 20240409090526.png]]