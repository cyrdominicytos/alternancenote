Jira>BUILD


V1, V2, etc : Point équipe (team meeting) : [SALTO-22271](https://portail.agir.orange.com/browse/SALTO-22271)
BR : BR
RH : Trasverse (Cross)
SPM : carte cérémonie agile () = > 2h

Voir les imputations
[https://portail.agir.orange.com/secure/Dashboard.jspa?selectPageId=24360](https://portail.agir.orange.com/secure/Dashboard.jspa?selectPageId=24360 "https://portail.agir.orange.com/secure/dashboard.jspa?selectpageid=24360")


![[Pasted image 20240321091645.png]]






OBS-FW-SCATFW-Data-TE-RSS-Router

