

| ENVS    | Détails                                                          |
| ------- | ---------------------------------------------------------------- |
| DEV     |                                                                  |
| Staging |                                                                  |
| AM      | Recette - terrain de jeu des PO/AF ( Les process sont respectés) |
| E1      | Environnement de pré-prod                                        |
