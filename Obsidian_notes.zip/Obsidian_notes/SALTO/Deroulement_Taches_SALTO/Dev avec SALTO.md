
proxyparfil.si.fr.intraorange

![[Pasted image 20240325101625.png]]
SALTO-21725 : Replace the field description  by reason on Danube response.

|                                                                                   |
| --------------------------------------------------------------------------------- |
| D_pzRunRecord.pxRunWindow(TABTHREAD0).pxRunResults.pxResults(1).WSResponsePage.ID |
OBS-MSDANUBE-WORK M-2859