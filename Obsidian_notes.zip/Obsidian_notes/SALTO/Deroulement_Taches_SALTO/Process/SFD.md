
Set US number as User

![[Pasted image 20240408160556.png]]