
https://confluence.constellation.soprasteria.com/pages/viewpage.action?pageId=250591644

Sur les versions

04-01-11 
04 version, augmente de 1 a chaque changement majeur de pega (montée de version)
01 skimm : augment de 1 a chaque
11 patch : augmente de 1 a chaque patch (maxi 4 patch possible) et augment de 5 a chaque nouvelle version ( lors des dev Secu)

L1V37I154 = V37 augment de 1 a chaque PI

Aller sur l'app INDUS = Faire des taches comme création de sprint (Create, new sprint)

Configuration
Ruleset : (OBS, SALTOFW, SCATFW, SALTOFWUn)

Application = nouvelle version 04-01-20
Produit = L1V37I153

**Pwd : retrocow**


Check rulesets : Records >sys admin > ruleSets
![[Pasted image 20240422105417.png]]