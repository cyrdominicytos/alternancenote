
Zap proxy : Analysen manuelle statique de 
Dependency-check : 

EPSS Score: Probability of exploitation
