
======= V1 ==========

Last week, I was officially awarded my Master's degree. I'd like to take this opportunity to thank the whole team for the support and contributions. 

Specially, Coline, Julien, Brendan for the training and preparation. A special thought to Coline, Julien and Brendan for the training and preparation. 

Thanks to all of them. And thanks to Sopra Steria management for giving me the opportunity to be part of the team.