
# SALTO-23584 : TYPE FAV

Vérifier qu'il y a un ticket créé côté OSCAR (voir avec Charles Deveau)

# SALTO-20156 : Problème de routage

Faire un point avec, 

# SALTO-23585

Fusionner 3 cartes et continuer l'analyse

# SALTO-12292


# SALTO-23617

