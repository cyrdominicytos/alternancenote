#12/07 

PB: BD (Reprise du Jalon remote ID)
"Prise de RDV en attente" : 

#10/07 

- [ ] Repasse sur tâche en anomalie (PB Connexion à la PROD) - ACT-25315492