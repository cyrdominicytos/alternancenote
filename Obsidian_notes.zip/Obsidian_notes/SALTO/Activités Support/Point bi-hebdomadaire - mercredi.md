
#12/07

Infos générale : 
[  ]commande en proposition dans  => elle va être envoyée à CLIP



#10/07
Faire une repasse sur les ticket dans le backlog
