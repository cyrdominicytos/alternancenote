
#15/07
20
At the support, 

20 tickets arrived last week and 26 was closed.  We beging the new week with 6 tickets in the backlog.


#09/07

For the support, 

We received **25** tickets last week and closed **20**, while at the beginning of the week it remain **12** tickets in the backlog.

Entrée : 25; Sortie : 20; Backlog : 12

We had a few drop-outs / abort during the last week because some actors replayed OFs by changing the OF number on the PROD.

#02/07

For the support,

We received **18** tickets last week and closed **25**, so on monday, it remain 7 tickets on the backlog.

179 rework cases in total for the month of June. Peak on 12/06 with 46 ARQ KO.

#25/06
For the support, 

We received **23** tickets last week and closed **19**, while at the beginning of the week we had **14** tickets pending.

Entrée : 23 ; Sortie : 19; Backlog : 14
6 tickets are currently being analyzed by the catalog.



